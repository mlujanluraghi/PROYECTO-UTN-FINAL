<?php

$conexion_db=mysqli_connect("localhost","root","","elecktricity_luraghi") or exit("No se conectó");

?>